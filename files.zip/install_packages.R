# Run this once to install everything the app needs
install.packages(c("shiny", "dplyr", "tidyr", "ggplot2", "DT", "readr", "readxl"))
