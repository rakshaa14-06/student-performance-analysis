# Student Performance Analysis System

An interactive dashboard built with **R and Shiny** to analyze student marks, find patterns and flag students who may need support.

## Features
- Upload your own data (`.csv`, `.xlsx`, `.xls`) or use built-in sample data of 150 students
- Map your own columns: student ID, subject marks, and factors such as attendance or study hours
- Calculates each student's average %, grade (A / B / C / Fail) and pass/fail result
- Interactive filters for average range and grades
- Charts: average distribution, grade distribution, subject-wise averages and box plots, scatter plot with trend line
- Correlation analysis and linear regression to see how factors such as attendance and study hours relate to performance
- Flags at-risk students using a predicted average and an adjustable threshold
- Download results as CSV

## Tech stack
R, Shiny, dplyr, tidyr, ggplot2, DT, readr, readxl

## How to run
1. Install [R](https://cran.r-project.org/) (and optionally RStudio).
2. Install the packages by running `install_packages.R`, or run:
   ```r
   install.packages(c("shiny", "dplyr", "tidyr", "ggplot2", "DT", "readr", "readxl"))
   ```
3. Download this repository, then in R run:
   ```r
   shiny::runApp("path/to/student-performance-analysis")
   ```
4. Use the sample data, or upload `sample_students.csv` to try the file upload.

## Data format
One row per student, with column names in the first row. Example:

| StudentID | Gender | Attendance | StudyHours | Math | Science | English | History | Computer |
|---|---|---|---|---|---|---|---|---|
| S001 | Female | 82 | 3.5 | 71 | 68 | 75 | 66 | 80 |

Subject and factor columns must be numeric.

## Screenshots
![Overview](screenshots/overview.png)
![Subjects](screenshots/subjects.png)
![Relationships](screenshots/relationships.png)
![At-Risk Students](screenshots/at-risk.png)

## Possible improvements
- Fit the regression on the full dataset rather than only the filtered students
- Add more models and model-accuracy metrics
- Deploy the app online (for example on shinyapps.io)

## Author
Rakshaa Jain, BCA (Data Analytics), Jain University
