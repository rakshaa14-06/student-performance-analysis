# Student Performance Analysis System - Shiny app (frontend + backend in R)
# Works with sample data OR your own CSV / Excel file.
# Setup:  install.packages(c("shiny","dplyr","tidyr","ggplot2","DT","readr","readxl"))
# Run:    shiny::runApp("student_app")

library(shiny)
library(dplyr)
library(tidyr)
library(ggplot2)
library(DT)
library(readr)
library(readxl)

# ---------------- BACKEND: data helpers ----------------
generate_data <- function(n = 150) {
  set.seed(42)
  Attendance <- round(pmin(100, pmax(40, rnorm(n, 78, 12))))
  StudyHours <- round(pmax(0, rnorm(n, 3.5, 1.5)), 1)
  score <- function() round(pmin(100, pmax(0, 20 + 0.4 * Attendance + 5 * StudyHours + rnorm(n, 0, 8))))
  data.frame(StudentID = sprintf("S%03d", 1:n),
             Gender = sample(c("Male", "Female"), n, replace = TRUE),
             Attendance = Attendance, StudyHours = StudyHours,
             Math = score(), Science = score(), English = score(),
             History = score(), Computer = score())
}

# Read .csv, .xlsx or .xls (Excel: first sheet is read)
read_any <- function(path, name) {
  ext <- tolower(tools::file_ext(name))
  d <- switch(ext,
              csv  = read_csv(path, show_col_types = FALSE),
              xlsx = , xls = read_excel(path),
              stop("Unsupported file type. Please use .csv, .xlsx or .xls"))
  d <- as.data.frame(d)
  names(d) <- trimws(names(d))
  d
}

grade_of <- function(avg) {
  factor(case_when(avg >= 75 ~ "A", avg >= 60 ~ "B", avg >= 40 ~ "C", TRUE ~ "Fail"),
         levels = c("A", "B", "C", "Fail"))
}

# ---------------- FRONTEND: UI ----------------
ui <- fluidPage(
  titlePanel("Student Performance Analysis System"),
  sidebarLayout(
    sidebarPanel(width = 3,
      fileInput("file", "Upload your data (.csv, .xlsx, .xls)",
                accept = c(".csv", ".xlsx", ".xls")),
      helpText("First row = column names, one row per student. 
               Excel: first sheet is used. No file = sample data."),
      downloadButton("template", "Download sample file"),
      hr(),
      h5("Map your columns"),
      selectInput("id_col", "Student ID / name column", choices = NULL),
      selectInput("subj_cols", "Subject / marks columns", choices = NULL, multiple = TRUE),
      selectInput("pred_cols", "Factors for prediction (e.g. attendance, study hours)",
                  choices = NULL, multiple = TRUE),
      numericInput("max_marks", "Maximum marks per subject", 100, min = 1),
      hr(),
      sliderInput("avg_range", "Average % range", 0, 100, c(0, 100)),
      selectizeInput("grades", "Grades", c("A", "B", "C", "Fail"),
                     selected = c("A", "B", "C", "Fail"), multiple = TRUE),
      sliderInput("risk", "At-risk threshold (predicted avg %)", 20, 80, 55),
      downloadButton("results", "Download results (CSV)")
    ),
    mainPanel(width = 9,
      tabsetPanel(
        tabPanel("Overview",
          fluidRow(
            column(3, wellPanel(h5("Students"), h3(textOutput("n_students")))),
            column(3, wellPanel(h5("Average %"), h3(textOutput("avg_mark")))),
            column(3, wellPanel(h5("Pass %"), h3(textOutput("pass_pct")))),
            column(3, wellPanel(h5("At risk"), h3(textOutput("n_risk"))))),
          fluidRow(column(6, plotOutput("hist_avg")), column(6, plotOutput("grade_bar")))),
        tabPanel("Subjects",
          fluidRow(column(6, plotOutput("subject_bar")), column(6, plotOutput("subject_box")))),
        tabPanel("Relationships",
          selectInput("xvar", "X-axis column", choices = NULL),
          plotOutput("scatter"), verbatimTextOutput("corr"), verbatimTextOutput("model_summary")),
        tabPanel("At-Risk Students", DTOutput("risk_table")),
        tabPanel("Data", DTOutput("data_table"))
      )
    )
  )
)

# ---------------- BACKEND: server ----------------
server <- function(input, output, session) {

  # 1. Load: uploaded CSV/Excel, otherwise sample data
  raw <- reactive({
    if (is.null(input$file)) return(generate_data())
    tryCatch(read_any(input$file$datapath, input$file$name),
             error = function(e) validate(need(FALSE, paste("Could not read file:", conditionMessage(e)))))
  })

  # 2. When data changes, auto-detect columns (user can change them)
  observe({
    d <- raw(); cols <- names(d)
    num <- cols[vapply(d, is.numeric, logical(1))]
    pr  <- num[grepl("attend|study|hour|sleep|absen", num, ignore.case = TRUE)]
    sj  <- setdiff(num, c(pr, cols[1]))
    updateSelectInput(session, "id_col", choices = cols, selected = cols[1])
    updateSelectInput(session, "subj_cols", choices = num, selected = sj)
    updateSelectInput(session, "pred_cols", choices = num, selected = pr)
    updateSelectInput(session, "xvar", choices = num, selected = if (length(pr)) pr[1] else num[1])
  })

  # 3. Clean + compute average % and grade
  data <- reactive({
    req(input$subj_cols, input$max_marks)
    d <- raw(); subj <- input$subj_cols
    validate(need(all(subj %in% names(d)), "Select the subject columns for this file."),
             need(all(vapply(d[subj], is.numeric, logical(1))), "Subject columns must be numeric."))
    d %>% drop_na(all_of(subj)) %>%
      mutate(Average = round(rowMeans(across(all_of(subj))) / input$max_marks * 100, 1),
             Grade = grade_of(Average),
             Result = ifelse(Average >= 40, "Pass", "Fail"))
  })

  filtered <- reactive({
    data() %>% filter(Average >= input$avg_range[1], Average <= input$avg_range[2],
                      Grade %in% input$grades)
  })

  # 4. Regression on the chosen factors
  model <- reactive({
    p <- input$pred_cols
    validate(need(length(p) > 0, "Select at least one factor column to build the model."),
             need(all(p %in% names(filtered())), "Select factor columns for this file."),
             need(nrow(filtered()) > 5, "Not enough students for the selected filters."))
    lm(reformulate(paste0("`", p, "`"), response = "Average"), data = filtered())
  })

  # 5. Predicted average + at-risk flag (if no factors chosen, uses actual average)
  scored <- reactive({
    d <- filtered(); p <- input$pred_cols
    d$Predicted <- if (length(p) > 0 && all(p %in% names(d))) round(predict(model(), newdata = d), 1) else d$Average
    d$AtRisk <- !is.na(d$Predicted) & d$Predicted < input$risk
    d
  })

  # KPI cards
  output$n_students <- renderText(nrow(filtered()))
  output$avg_mark   <- renderText(round(mean(filtered()$Average), 1))
  output$pass_pct   <- renderText(paste0(round(mean(filtered()$Result == "Pass") * 100, 1), "%"))
  output$n_risk     <- renderText(sum(scored()$AtRisk))

  # Overview plots
  output$hist_avg <- renderPlot({
    ggplot(filtered(), aes(Average)) +
      geom_histogram(binwidth = 5, fill = "#0FA3B1", colour = "white") +
      labs(title = "Distribution of average %", x = "Average %", y = "Students") + theme_minimal(base_size = 14)
  })
  output$grade_bar <- renderPlot({
    ggplot(filtered(), aes(Grade, fill = Grade)) + geom_bar(show.legend = FALSE) +
      scale_fill_manual(values = c(A = "#0FA3B1", B = "#1E2A4A", C = "#7FB3D5", Fail = "#E07A5F"), drop = FALSE) +
      scale_x_discrete(drop = FALSE) +
      labs(title = "Grade distribution", y = "Students") + theme_minimal(base_size = 14)
  })

  # Subject plots
  long <- reactive(filtered() %>% pivot_longer(all_of(input$subj_cols), names_to = "Subject", values_to = "Marks"))
  output$subject_bar <- renderPlot({
    long() %>% group_by(Subject) %>% summarise(Mean = mean(Marks, na.rm = TRUE)) %>%
      ggplot(aes(reorder(Subject, Mean), Mean)) + geom_col(fill = "#0FA3B1") +
      geom_text(aes(label = round(Mean, 1)), hjust = -0.2) + coord_flip() +
      labs(title = "Average marks by subject", x = NULL, y = "Mean marks") + theme_minimal(base_size = 14)
  })
  output$subject_box <- renderPlot({
    ggplot(long(), aes(Subject, Marks, fill = Subject)) + geom_boxplot(show.legend = FALSE) +
      labs(title = "Spread of marks by subject") + theme_minimal(base_size = 14)
  })

  # Relationships
  output$scatter <- renderPlot({
    validate(need(input$xvar %in% names(filtered()), "Choose a numeric column for the X-axis."))
    ggplot(filtered(), aes(x = .data[[input$xvar]], y = Average)) +
      geom_point(size = 2.5, alpha = 0.8, colour = "#1E2A4A") +
      geom_smooth(method = "lm", formula = y ~ x, colour = "#E07A5F") +
      labs(title = paste(input$xvar, "vs average %"), x = input$xvar, y = "Average %") + theme_minimal(base_size = 14)
  })
  output$corr <- renderPrint({
    for (v in input$pred_cols) {
      cat("Correlation (", v, ", Average): ",
          round(cor(filtered()[[v]], filtered()$Average, use = "complete.obs"), 3), "\n", sep = "")
    }
  })
  output$model_summary <- renderPrint(summary(model()))

  # Tables
  output$risk_table <- renderDT({
    scored() %>% filter(AtRisk) %>%
      select(any_of(c(input$id_col, input$pred_cols, "Average", "Predicted", "Grade"))) %>%
      arrange(Predicted) %>% datatable(options = list(pageLength = 10))
  })
  output$data_table <- renderDT(datatable(scored(), options = list(pageLength = 10)))

  # Downloads
  output$results  <- downloadHandler(filename = function() "student_analysis_results.csv",
                                     content = function(file) write.csv(scored(), file, row.names = FALSE))
  output$template <- downloadHandler(filename = function() "sample_students.csv",
                                     content = function(file) write.csv(generate_data(20), file, row.names = FALSE))
}

shinyApp(ui, server)
